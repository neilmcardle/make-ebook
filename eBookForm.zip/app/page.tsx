import EbookForm from "@/components/EbookForm"

export default function Home() {
  return (
    <main className="container mx-auto p-4">
      <EbookForm />
    </main>
  )
}

